package com.example.projectappsos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
