import 'package:flutter/material.dart';
import 'package:projectappsos/profile_screen.dart';
import 'emergency_contacts_screen.dart';
import 'emergency_numbers_screen.dart';
import 'sos_confirmation_screen.dart'; // นำเข้าหน้าใหม่

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          SizedBox(height: 50), // ระยะห่างจากด้านบน
          Text(
            "คุณต้องการขอความช่วยเหลือ หรือไม่?",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            textAlign: TextAlign.center,
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                try {
                  // นำทางไปหน้า SosConfirmationScreen เมื่อกดวงกลม SOS
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SosConfirmationScreen()),
                  ).then((value) {
                    print("Returned to HomeScreen from SosConfirmationScreen");
                  });
                } catch (e) {
                  print("Error navigating to SosConfirmationScreen: $e");
                }
              },
              child: Center(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 300,
                      height: 300,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromRGBO(255, 216, 215, 1.0), // สี #FFD8D7 (ชมพูอ่อน)
                      ),
                    ),
                    Container(
                      width: 250,
                      height: 250,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromRGBO(246, 135, 133, 1.0), // สี #F68785 (แดงอมชมพู)
                      ),
                    ),
                    Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromRGBO(230, 70, 70, 1.0), // สีแดงเข้ม
                      ),
                    ),
                    Text(
                      'SOS',
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 20),
            child: Text(
              "กดปุ่มSOS เพื่อโทรขอความช่วยเหลือ",
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Container(
            color: Colors.white,
            child: BottomNavigationBar(
              items: [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home, color: Colors.red),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.phone, color: Colors.grey),
                  label: 'Emergency Numbers',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.contacts, color: Colors.grey),
                  label: 'Emergency Contacts',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person, color: Colors.grey),
                  label: 'Profile',
                ),
              ],
              currentIndex: 0,
              selectedItemColor: Colors.red,
              unselectedItemColor: Colors.grey,
              type: BottomNavigationBarType.fixed,
              onTap: (index) {
                try {
                  switch (index) {
                    case 0:
                      break;
                    case 1:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => EmergencyNumbersScreen()),
                      );
                      break;
                    case 2:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => EmergencyContactsScreen()),
                      );
                      break;
                    case 3:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ProfileScreen()),
                      );
                      break;
                    default:
                      break;
                  }
                } catch (e) {
                  print("Error navigating: $e");
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}