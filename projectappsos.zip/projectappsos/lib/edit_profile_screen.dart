import 'package:flutter/material.dart';
import 'package:projectappsos/emergency_contacts_screen.dart';
import 'package:projectappsos/emergency_numbers_screen.dart';
import 'package:projectappsos/home_screen.dart';

class EditProfileScreen extends StatefulWidget {
  final Map<String, dynamic> userProfile;

  EditProfileScreen({required this.userProfile});

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final TextEditingController fullNameController = TextEditingController();
  String? gender;
  String? bloodType;
  final TextEditingController medicalConditionsController = TextEditingController();
  final TextEditingController allergiesController = TextEditingController();
  String errorMessage = '';

  // รายการตัวเลือกสำหรับ Dropdown
  final List<String> genderOptions = ['ชาย', 'หญิง', 'อื่น ๆ'];
  final List<String> bloodTypeOptions = ['A', 'B', 'O', 'AB'];

  @override
  void initState() {
    super.initState();
    // เริ่มต้นด้วยข้อมูลจาก userProfile
    fullNameController.text = widget.userProfile['fullName'] ?? '';
    gender = widget.userProfile['gender'];
    bloodType = widget.userProfile['bloodType'];
    medicalConditionsController.text = widget.userProfile['medicalConditions'] ?? '';
    allergiesController.text = widget.userProfile['allergies'] ?? '';
  }

  void saveProfile() {
    String fullName = fullNameController.text.trim();
    String medicalConditions = medicalConditionsController.text.trim();
    String allergies = allergiesController.text.trim();

    // ตรวจสอบว่าข้อมูลกรอกครบหรือไม่
    if (fullName.isEmpty || gender == null || bloodType == null || medicalConditions.isEmpty || allergies.isEmpty) {
      setState(() {
        errorMessage = 'กรุณากรอกข้อมูลให้ครบถ้วน';
      });
      return;
    }

    // ส่งข้อมูลที่อัปเดตกลับไป (Mock Data)
    Navigator.pop(context, {
      'fullName': fullName,
      'gender': gender,
      'bloodType': bloodType,
      'medicalConditions': medicalConditions,
      'allergies': allergies,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("แก้ไขโปรไฟล์"),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "แก้ไขโปรไฟล์",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 20),
              TextField(
                controller: fullNameController,
                decoration: InputDecoration(
                  labelText: "ชื่อ-นามสกุล",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: "เพศ",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline),
                ),
                value: gender,
                items: genderOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    gender = newValue;
                  });
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: "หมู่เลือด",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.favorite),
                ),
                value: bloodType,
                items: bloodTypeOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    bloodType = newValue;
                  });
                },
              ),
              SizedBox(height: 10),
              TextField(
                controller: medicalConditionsController,
                decoration: InputDecoration(
                  labelText: "โรคประจำตัว",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.medical_services),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: allergiesController,
                decoration: InputDecoration(
                  labelText: "การแพ้ยา",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.medication),
                ),
              ),
              SizedBox(height: 10),
              Text(
                errorMessage,
                style: TextStyle(color: Colors.red),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: saveProfile,
                child: Text("บันทึก", style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.grey),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu, color: Colors.grey),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add, color: Colors.grey),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.red),
            label: 'User',
          ),
        ],
        currentIndex: 3, // เลือก User เป็นหน้าเริ่มต้น
        selectedItemColor: Colors.red,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyNumbersScreen()),
              );
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyContactsScreen()),
              );
              break;
            case 3:
            // อยู่หน้า Profile (ไม่ต้องเปลี่ยน)
              break;
          }
        },
      ),
    );
  }
}