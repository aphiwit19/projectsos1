import 'package:flutter/material.dart';
import 'profile_screen.dart'; // กลับไปหน้าโปรไฟล์
import 'home_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'emergency_numbers_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'emergency_contacts_screen.dart'; // เพิ่มการเชื่อมต่อ

class HistoryScreen extends StatelessWidget {
  // Mock Data สำหรับประวัติการแจ้งเหตุ
  final List<Map<String, String>> history = [
    {'date': '28/02/2025', 'time': '09:41', 'status': 'ส่งสำเร็จ'},
    {'date': '27/02/2025', 'time': '15:30', 'status': 'ส่งสำเร็จ'},
    {'date': '26/02/2025', 'time': '12:15', 'status': 'ยกเลิก'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("ประวัติการแจ้งเหตุ"),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey[300],
              ),
              child: Icon(Icons.history, color: Colors.red, size: 50),
            ),
            SizedBox(height: 20),
            Text(
              "ประวัติการแจ้งเหตุ",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: history.length,
                itemBuilder: (context, index) {
                  final item = history[index];
                  return Card(
                    margin: EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      title: Text("แจ้งเหตุ SOS"),
                      subtitle: Text(
                        "วันที่: ${item['date']}, เวลา: ${item['time']} – ${item['status']}",
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.grey),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu, color: Colors.grey),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add, color: Colors.grey),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.red),
            label: 'User',
          ),
        ],
        currentIndex: 3, // เลือก User เป็นหน้าเริ่มต้น (เนื่องจากเกี่ยวข้องกับโปรไฟล์)
        selectedItemColor: Colors.red,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyNumbersScreen()),
              );
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyContactsScreen()),
              );
              break;
            case 3:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
              break;
          }
        },
      ),
    );
  }
}