import 'package:flutter/material.dart';
import 'edit_profile_screen.dart'; // ไปหน้าแก้ไขโปรไฟล์
import 'history_screen.dart'; // ไปหน้าประวัติการแจ้งเหตุ
import 'login_screen.dart'; // ไปหน้าล็อกอินเมื่อออกจากระบบ
import 'home_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'emergency_numbers_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'emergency_contacts_screen.dart'; // เพิ่มการเชื่อมต่อ

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Mock Data จาก user_profile_screen.dart
  final Map<String, dynamic> userProfile = {
    'fullName': 'สมชาย ใจดี',
    'gender': 'ชาย',
    'bloodType': 'O',
    'medicalConditions': 'ไม่มี',
    'allergies': 'ยาแก้ปวด',
  };

  void _editProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditProfileScreen(userProfile: userProfile)),
    ).then((updatedProfile) {
      if (updatedProfile != null && updatedProfile is Map<String, dynamic>) {
        setState(() {
          userProfile.clear();
          userProfile.addAll(updatedProfile);
        });
      }
    });
  }

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  void _viewHistory() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => HistoryScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("โปรไฟล์"),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView( // รักษาเพื่อแก้ปัญหา Bottom Overflow
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey[300], // ไอคอนสีเทา
              ),
              child: Icon(Icons.person, color: Colors.red, size: 50), // ไอคอนสีแดง
            ),
            SizedBox(height: 20),
            Text(
              "โปรไฟล์",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            Card(
              color: Color(0xFFD8DADC), // พื้นหลังกรอบเป็นสี #D8DADC ตามคำขอ
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15), // ขอบมนตามภาพ
                side: BorderSide(color: Colors.grey[300]!), // เส้นขอบสีเทา
              ),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end, // จัดปุ่มไปมุมขวา
                      children: [
                        ElevatedButton(
                          onPressed: _editProfile,
                          child: Text("แก้ไขโปรไฟล์", style: TextStyle(fontSize: 16, color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red, // สีแดงตามภาพ
                            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20), // ขนาดปุ่มเล็กลง
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10), // ขอบมนตามภาพ
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10), // ระยะห่างหลังปุ่ม
                    Text(
                      "ชื่อ-นามสกุล",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(userProfile['fullName'] ?? 'ไม่ระบุ', style: TextStyle(fontSize: 14)),
                    SizedBox(height: 10),
                    Text(
                      "เพศ",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(userProfile['gender'] ?? 'ไม่ระบุ', style: TextStyle(fontSize: 14)),
                    SizedBox(height: 10),
                    Text(
                      "หมู่เลือด",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(userProfile['bloodType'] ?? 'ไม่ระบุ', style: TextStyle(fontSize: 14)),
                    SizedBox(height: 10),
                    Text(
                      "โรคประจำตัว",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(userProfile['medicalConditions'] ?? 'ไม่ระบุ', style: TextStyle(fontSize: 14)),
                    SizedBox(height: 10),
                    Text(
                      "การแพ้ยา",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(userProfile['allergies'] ?? 'ไม่ระบุ', style: TextStyle(fontSize: 14)),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            TextButton(
              onPressed: _viewHistory,
              child: Text("ประวัติการแจ้งเหตุ", style: TextStyle(fontSize: 16, color: Colors.blue)),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _logout,
              child: Text("ออกจากระบบ", style: TextStyle(fontSize: 18, color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, // สีแดงตามภาพ
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // ขอบมนตามภาพ
                ),
              ),
            ),
            SizedBox(height: 20), // ระยะห่างเพิ่มเพื่อป้องกัน Overflow
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.grey),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu, color: Colors.grey),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add, color: Colors.grey),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.red), // ไอคอน User สีแดงตามภาพ
            label: 'User',
          ),
        ],
        currentIndex: 3, // เลือก User เป็นหน้าเริ่มต้น
        selectedItemColor: Colors.red,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyNumbersScreen()),
              );
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyContactsScreen()),
              );
              break;
            case 3:
            // อยู่หน้า Profile (ไม่ต้องเปลี่ยน)
              break;
          }
        },
      ),
    );
  }
}