import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'home_screen.dart'; // ไปหน้า Home หลังบันทึกสำเร็จ

class UserProfileScreen extends StatefulWidget {
  @override
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final TextEditingController fullNameController = TextEditingController();
  String? gender;
  String? bloodType;
  final TextEditingController medicalConditionsController =
      TextEditingController();
  final TextEditingController allergiesController = TextEditingController();
  String errorMessage = '';

  final List<String> genderOptions = ['ชาย', 'หญิง', 'อื่น ๆ'];
  final List<String> bloodTypeOptions = ['A', 'B', 'O', 'AB'];

  Future<void> saveProfile() async {
    String fullName = fullNameController.text.trim();
    String medicalConditions = medicalConditionsController.text.trim();
    String allergies = allergiesController.text.trim();

    if (fullName.isEmpty ||
        gender == null ||
        bloodType == null ||
        medicalConditions.isEmpty ||
        allergies.isEmpty) {
      setState(() {
        errorMessage = 'กรุณากรอกข้อมูลให้ครบถ้วน';
      });
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('hasProfile', true);
    await prefs.setString('fullName', fullName);
    await prefs.setString('gender', gender!);
    await prefs.setString('bloodType', bloodType!);
    await prefs.setString('medicalConditions', medicalConditions);
    await prefs.setString('allergies', allergies);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // ตั้งพื้นหลังทั้งหน้าเป็นสีขาว

      body: Container(
        color: Colors.white, // ตั้ง Container เป็นสีขาวด้วย
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "ข้อมูลพื้นฐาน",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 20),
              TextField(
                controller: fullNameController,
                decoration: InputDecoration(
                  labelText: "ชื่อ-นามสกุล",
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10), // เพิ่มมุมโค้ง
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.grey[200], // สีเทาอ่อนในช่องกรอก
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              SizedBox(height: 20), // เพิ่มระยะห่างระหว่างช่อง
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: "เพศ",
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.grey[200], // สีเทาอ่อนในช่องกรอก
                  prefixIcon: Icon(Icons.person_outline),
                ),
                value: gender,
                items: genderOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    gender = newValue;
                  });
                },
              ),
              SizedBox(height: 20), // เพิ่มระยะห่างระหว่างช่อง
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: "หมู่เลือด",
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.grey[200], // สีเทาอ่อนในช่องกรอก
                  prefixIcon: Icon(Icons.favorite),
                ),
                value: bloodType,
                items: bloodTypeOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    bloodType = newValue;
                  });
                },
              ),
              SizedBox(height: 20), // เพิ่มระยะห่างระหว่างช่อง
              TextField(
                controller: medicalConditionsController,
                decoration: InputDecoration(
                  labelText: "โรคประจำตัว",
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.grey[200], // สีเทาอ่อนในช่องกรอก
                  prefixIcon: Icon(Icons.medical_services),
                ),
              ),
              SizedBox(height: 20), // เพิ่มระยะห่างระหว่างช่อง
              TextField(
                controller: allergiesController,
                decoration: InputDecoration(
                  labelText: "การแพ้ยา",
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.grey[200], // สีเทาอ่อนในช่องกรอก
                  prefixIcon: Icon(Icons.medication),
                ),
              ),
              SizedBox(height: 20),
              Text(
                errorMessage,
                style: TextStyle(color: Color.fromRGBO(230, 70, 70, 1.0)),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: saveProfile,
                child: Text(
                  "บันทึก",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromRGBO(230, 70, 70, 1.0),
                  padding: EdgeInsets.symmetric(
                      vertical: 15, horizontal: 40), // ปรับขนาดปุ่ม
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(30), // ทำให้ปุ่มโค้งตามภาพ
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
