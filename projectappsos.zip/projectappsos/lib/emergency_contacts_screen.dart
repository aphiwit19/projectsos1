import 'package:flutter/material.dart';
import 'add_emergency_contact_screen.dart';
import 'edit_emergency_contact_screen.dart';

void main() {
  runApp(MaterialApp(
    home: EmergencyContactsScreen(),
    theme: ThemeData(
      primaryColor: Colors.white,
      scaffoldBackgroundColor: const Color.fromRGBO(244, 244, 244, 1.0), // ปรับที่นี่
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, elevation: 0),
    ),
  ));
}

class EmergencyContactsScreen extends StatefulWidget {
  const EmergencyContactsScreen({Key? key}) : super(key: key);

  @override
  State<EmergencyContactsScreen> createState() => _EmergencyContactsScreenState();
}

class _EmergencyContactsScreenState extends State<EmergencyContactsScreen> {
  List<Map<String, String>> contacts = [];

  void _addContact() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddEmergencyContactScreen(
          onContactAdded: (name, phone) {
            setState(() {
              contacts.add({'name': name, 'phone': phone});
            });
          },
        ),
      ),
    );
  }

  void _editContact(String currentName, String currentPhone) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditEmergencyContactScreen(
          currentName: currentName,
          currentPhone: currentPhone,
          onContactUpdated: (name, phone) {
            setState(() {
              int index = contacts.indexWhere((contact) => contact['name'] == currentName);
              if (index != -1) {
                contacts[index] = {'name': name, 'phone': phone};
              }
            });
          },
        ),
      ),
    );
  }

  void _deleteContact(String name) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 20),
              const Text(
                "คุณแน่ใจหรือไม่?",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                "คุณต้องการลบ \"$name\" ออกจากรายการผู้ติดต่อฉุกเฉิน?",
                style: const TextStyle(fontSize: 16, color: Colors.black54),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("ยกเลิก",
                        style: TextStyle(fontSize: 16, color: Colors.black)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[300],
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        contacts.removeWhere((contact) => contact['name'] == name);
                      });
                      Navigator.pop(context);
                    },
                    child: const Text("ยืนยัน",
                        style: TextStyle(fontSize: 16, color: Colors.white)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromRGBO(230, 70, 70, 1.0),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(244, 244, 244, 1.0), // ปรับที่นี่
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "ผู้ติดต่อฉุกเฉิน",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: contacts.isEmpty ? _buildEmptyState() : _buildContactList(),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.home), label: ''),
          const BottomNavigationBarItem(icon: Icon(Icons.grid_view), label: ''),
          BottomNavigationBarItem(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: Color.fromRGBO(230, 70, 70, 1.0),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.add, color: Colors.white),
                  SizedBox(width: 5),
                  Text("Add", style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
            label: '',
          ),
          const BottomNavigationBarItem(icon: Icon(Icons.person), label: ''),
        ],
        currentIndex: 2,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        onTap: (index) {
          if (index == 2) _addContact(); // กด + เพื่อไปหน้าเพิ่ม
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey,
              ),
            ),
            Container(
              width: 100,
              height: 100,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color.fromRGBO(230, 70, 70, 1.0),
              ),
              child: const Stack(
                alignment: Alignment.center,
                children: [
                  Icon(Icons.group, size: 50, color: Colors.white),
                  Positioned(
                      right: 30,
                      bottom: 30,
                      child: Icon(Icons.add, size: 30, color: Colors.white)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 40),
        const Text(
          "เพิ่มผู้ติดต่อฉุกเฉิน",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10),
        const Text(
          "เพิ่มผู้ติดต่อฉุกเฉินเพื่อให้คุณสามารถแจ้งเตือนได้ทันที",
          style: TextStyle(fontSize: 14, color: Colors.black54),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 40),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _addContact,
            child: const Text("เพิ่มผู้ติดต่อ",
                style: TextStyle(fontSize: 18, color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color.fromRGBO(230, 70, 70, 1.0),
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(30))),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContactList() {
    return Column(
      children: [
        GestureDetector(
          onTap: _addContact, // กดเพื่อไปหน้าเพิ่มผู้ติดต่อ
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                width: 75,
                height: 70,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color.fromRGBO(230, 70, 70, 1.0),
                ),
                child: const Icon(
                  Icons.add,
                  color: Colors.white,
                  size: 45,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                "เพิ่มผู้ติดต่อรายใหม่",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(230, 70, 70, 1.0),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 40),
        Expanded(
          child: ListView.builder(
            itemCount: contacts.length,
            itemBuilder: (context, index) {
              final contact = contacts[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                color: Colors.white,
                child: ListTile(
                  title: Text(contact['name']!, style: const TextStyle(fontSize: 16)),
                  subtitle: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.phone, color: Colors.grey, size: 16),
                          const SizedBox(width: 5),
                          Text(contact['phone']!,
                              style: const TextStyle(fontSize: 14, color: Colors.grey)),
                        ],
                      ),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert, color: Colors.grey),
                        onSelected: (String value) {
                          if (value == 'edit') {
                            _editContact(contact['name']!, contact['phone']!);
                          } else if (value == 'delete') {
                            _deleteContact(contact['name']!);
                          }
                        },
                        itemBuilder: (BuildContext context) => [
                          PopupMenuItem<String>(
                            value: 'edit',
                            child: const ListTile(
                              leading: Icon(Icons.edit, color: Colors.grey),
                              title: Text('แก้ไข'),
                            ),
                          ),
                          PopupMenuItem<String>(
                            value: 'delete',
                            child: const ListTile(
                              leading: Icon(
                                  Icons.delete, color: Color.fromRGBO(230, 70, 70, 1.0)),
                              title: Text('ลบ'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}