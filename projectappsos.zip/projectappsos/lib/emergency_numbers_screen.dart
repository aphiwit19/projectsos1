import 'package:flutter/material.dart';
import 'home_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'emergency_contacts_screen.dart'; // เพิ่มการเชื่อมต่อ
import 'profile_screen.dart'; // เพิ่มการเชื่อมต่อ

class EmergencyNumbersScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // ข้อมูลเบอร์ฉุกเฉินจากภาพ
    final List<Map<String, String>> emergencyNumbers = [
      // เหตุดurgentเหตุร้าย (สีแดง)
      {'category': 'เหตุดurgentเหตุร้าย', 'service': 'ตำรวจ', 'number': '191'},
      {'category': 'เหตุดurgentเหตุร้าย', 'service': 'สายด่วน 199', 'number': '199'},
      {'category': 'เหตุดurgentเหตุร้าย', 'service': 'กู้ภัยมูลนิธิ', 'number': '1196'},
      // กรณีเจ็บป่วย (สีส้ม)
      {'category': 'กรณีเจ็บป่วย', 'service': 'โรงพยาบาล', 'number': '1154'},
      {'category': 'กรณีเจ็บป่วย', 'service': 'สายด่วนปฐมพยาบาล', 'number': '1669'},
      {'category': 'กรณีเจ็บป่วย', 'service': 'สายด่วนพิษภัย', 'number': '1646'},
      // แจ้งเหตุจราจร-ขอความช่วยเหลือ (สีน้ำเงิน)
      {'category': 'แจ้งเหตุจราจร-ขอความช่วยเหลือ', 'service': 'สายด่วนจราจร', 'number': '1586'},
      {'category': 'แจ้งเหตุจราจร-ขอความช่วยเหลือ', 'service': 'สายด่วนกรมทางหลวง', 'number': '1197'},
      {'category': 'แจ้งเหตุจราจร-ขอความช่วยเหลือ', 'service': 'สายด่วนกรมทางด่วน', 'number': '1137'},
    ];

    return Scaffold(
      backgroundColor: Colors.grey[200], // พพื้นหลังสีเทาอ่อน
      appBar: AppBar(
        title: Text("เบอร์ฉุกเฉิน"),
      ),
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          // เหตุดurgentเหตุร้าย (สีแดง)
          Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "เหตุดurgentเหตุร้าย",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          ...emergencyNumbers
              .where((number) => number['category'] == 'เหตุดurgentเหตุร้าย')
              .map((number) => _buildEmergencyTile(number['service']!, number['number']!))
              .toList(),
          SizedBox(height: 10),

          // กรณีเจ็บป่วย (สีส้ม)
          Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "กรณีเจ็บป่วย",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          ...emergencyNumbers
              .where((number) => number['category'] == 'กรณีเจ็บป่วย')
              .map((number) => _buildEmergencyTile(number['service']!, number['number']!))
              .toList(),
          SizedBox(height: 10),

          // แจ้งเหตุจราจร-ขอความช่วยเหลือ (สีน้ำเงิน)
          Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "แจ้งเหตุจราจร-ขอความช่วยเหลือ",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          ...emergencyNumbers
              .where((number) => number['category'] == 'แจ้งเหตุจราจร-ขอความช่วยเหลือ')
              .map((number) => _buildEmergencyTile(number['service']!, number['number']!))
              .toList(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.grey),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu, color: Colors.red),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add, color: Colors.grey),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.grey),
            label: 'User',
          ),
        ],
        currentIndex: 1, // เลือก Menu เป็นหน้าเริ่มต้น
        selectedItemColor: Colors.red,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
              break;
            case 1:
            // อยู่หน้า Emergency Numbers (ไม่ต้องเปลี่ยน)
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EmergencyContactsScreen()),
              );
              break;
            case 3:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
              break;
          }
        },
      ),
    );
  }

  // ฟังก์ชันสร้าง Tile สำหรับเบอร์ฉุกเฉิน
  Widget _buildEmergencyTile(String service, String number) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      child: ListTile(
        leading: Icon(Icons.phone, color: Colors.red),
        title: Text(service),
        trailing: Text(number, style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
        onTap: () {
          // ฟังก์ชันโทรออก (ทดสอบ Mock)
          print("โทรไปยัง: $number (Mock Data)");
        },
      ),
    );
  }
}